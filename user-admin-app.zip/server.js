
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const db = new sqlite3.Database('./users.db');

// Inicializace databáze
db.serialize(() => {
  db.run(\`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT,
      isAdmin INTEGER
    )
  \`);

  const defaultAdminPassword = bcrypt.hashSync('pass999', 10);
  db.run(\`
    INSERT OR IGNORE INTO users (username, password, isAdmin)
    VALUES ('admin', ?, 1)
  \`, [defaultAdminPassword]);
});

app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new SQLiteStore,
  secret: 'tajnyklic',
  resave: false,
  saveUninitialized: false
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));

// Middleware pro autentizaci
function ensureAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

function ensureAdmin(req, res, next) {
  if (!req.session.user || !req.session.user.isAdmin) return res.redirect('/');
  next();
}

// ROUTES
app.get('/', ensureAuth, (req, res) => {
  res.redirect(req.session.user.isAdmin ? '/admin' : '/profile');
});

app.get('/login', (req, res) => res.render('login'));
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err || !user || !bcrypt.compareSync(password, user.password)) {
      return res.render('login', { error: 'Neplatné údaje' });
    }
    req.session.user = { id: user.id, username: user.username, isAdmin: !!user.isAdmin };
    res.redirect('/');
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

app.get('/profile', ensureAuth, (req, res) => {
  res.render('profile', { user: req.session.user });
});

app.post('/profile/password', ensureAuth, (req, res) => {
  const { newPassword } = req.body;
  const hashed = bcrypt.hashSync(newPassword, 10);
  db.run('UPDATE users SET password = ? WHERE id = ?', [hashed, req.session.user.id], () => {
    res.redirect('/profile');
  });
});

app.get('/admin', ensureAdmin, (req, res) => {
  db.all('SELECT id, username, isAdmin FROM users', (err, users) => {
    res.render('admin', { user: req.session.user, users });
  });
});

app.post('/admin/reset', ensureAdmin, (req, res) => {
  const { userId, newPassword } = req.body;
  if (userId == 1) return res.redirect('/admin');
  const hashed = bcrypt.hashSync(newPassword, 10);
  db.run('UPDATE users SET password = ? WHERE id = ?', [hashed, userId], () => {
    res.redirect('/admin');
  });
});

app.post('/admin/add-admin', ensureAdmin, (req, res) => {
  const { userId } = req.body;
  if (userId == 1) return res.redirect('/admin');
  db.run('UPDATE users SET isAdmin = 1 WHERE id = ?', [userId], () => {
    res.redirect('/admin');
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Server běží na portu ' + port));
